# FG style colors
fg_green = "#50AE26"
fg_blue = "#336699"
fg_orange = "#FBAC26"
fg_red = "#CE4A49"
fg_graph_highlight = "#FCC531"

# Strike zone coordinates
sz_bot = 1.7544
sz_top = 3.4248
sz_left = -.7083333
sz_right = .7083333