team = function(x, hometeam, awayteam) {
  if (x <= 9) {
    return(awayteam)
  } else {
    return(hometeam)
  }
}