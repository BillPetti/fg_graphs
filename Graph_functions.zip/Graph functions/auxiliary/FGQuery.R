FGQuery = function(query) {
  con=dbConnect(RMySQL::MySQL(), dbname = "tht", username = "jonah.pemstein", password = "TSLwqjF9D", host = "db.fangraphs.com")
  data = dbGetQuery(con, query)
  cons = dbListConnections(MySQL())
  for(con in cons) {dbDisconnect(con)}
  return(data)
}